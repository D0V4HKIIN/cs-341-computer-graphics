Task RT 1.1
For plane intersection, the exercise is trivial. We applied the formula from the lecture and observe the fact that the plane normal is the normal we want. We also adjust normal's direction to make sure it has the opposite direction comparing to ray.

Task RT 2.1
You can find detailed derivation in TheoryExercise.pdf

Task RT 2.2
Implementation simple follows the implicit formula we derived and we also add code to make sure the intersection points fall within the reachable range  of the cylinder. The normals are flipped if the ray is in the same direction as the calculated normal.

Work Contribution:
We all showed up in the exercises and stayed to work together after. The workload was distributed evenly.
